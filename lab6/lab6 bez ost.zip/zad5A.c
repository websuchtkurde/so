#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <string.h>
#include <wait.h>
#include <unistd.h>
void funkcja(int semafor_id, char *wspoldzielone)
{
	struct sembuf wait_operation = {0, 0, 0};
	struct sembuf up_operation = {0, 1, 0};
	int i;
	for(i = 0; i < 3; i++)
	{
		semop(semafor_id, &wait_operation, 1);
		
		char toSave[20] = "jakis tekst nr: ";
		char xd = i + '0';
		strcat(toSave, &xd);
		strcpy(wspoldzielone, toSave);
		
		semop(semafor_id, &up_operation, 1);
		
		sleep(1);
	}

	printf("Koniec\n");
}

int main(void)
{
	int id_pamieci = ftok("zad4A.c", 9);
	int id_semafora = ftok("zad4A.c", 2);
	
	int id = shmget(id_pamieci, 50, IPC_CREAT | 0660);
	int semafor_id = semget(id_semafora, 1, 0600 | IPC_CREAT);
	
	semctl(semafor_id, 1, SETVAL, 1);

	char *wspoldzielone = shmat(id, NULL, 0);
	
	funkcja(semafor_id,wspoldzielone);
	
}

//NAJPIERW URUCHOMIĆ PROGRAM 4B - inaczej się zbuguje i przy kolejnych uruchomieniach nie zadziała poprawnie
