#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <string.h>
void funkcja(int id,int semafor_id,char *wspoldzielone){
	struct shmid_ds bufor;
struct sembuf down_operation = {0, -1, 0};
	
	int i;
	for(i = 0; i < 3; i++)
	{
		if(i == 2)
		{
			shmctl(id, IPC_STAT, &bufor);
			char *mode = "600";
		  	sscanf(mode, "%o", &bufor.shm_perm.mode);
		  	shmctl(id, IPC_SET, &bufor);
		    	printf("Zmieniono prawa dostępu na: %o\n", bufor.shm_perm.mode);
		}
		
		semop(semafor_id, &down_operation, 1);
	
		printf("Tekst odczytany z obszaru pamięci współdzielonej: %s\n", wspoldzielone);
	}
	
	shmctl(id, IPC_RMID, 0);

}

int main(void)
{
	int id_pamieci = ftok("zad4A.c", 9);
	int id_semafora = ftok("zad4A.c", 2);
	
	int id = shmget(id_pamieci, 50, IPC_CREAT | 0660);
	int semafor_id = semget(id_semafora, 1, 0600 | IPC_CREAT);

	char *wspoldzielone = shmat(id, NULL, 0);
	funkcja(id,semafor_id,wspoldzielone);
	/*struct sembuf down_operation = {0, -1, 0};
	
	int i;
	for(i = 0; i < 3; i++)
	{
		if(i == 2)
		{
			shmctl(id, IPC_STAT, &bufor);
			char *mode = "600";
		  	sscanf(mode, "%o", &bufor.shm_perm.mode);
		  	shmctl(id, IPC_SET, &bufor);
		    	printf("Zmieniono prawa dostępu na: %o\n", bufor.shm_perm.mode);
		}
		
		semop(semafor_id, &down_operation, 1);
	
		printf("Tekst odczytany z obszaru pamięci współdzielonej: %s\n", wspoldzielone);
	}
	
	shmctl(id, IPC_RMID, 0);*/
}
